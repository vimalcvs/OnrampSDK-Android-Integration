package arnavigation.appsan.com.myapplication

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Enum class representing supported cryptocurrency codes.
 */
enum class CryptoCode(val code: String, val displayName: String) {
    ETH("ETH", "Ethereum"),
    USDT("USDT", "Tether USD"),
    MATIC("MATIC", "Polygon"),
    BNB("BNB", "Binance Coin"),
    SOL("SOL", "Solana"),
    AVAX("AVAX", "Avalanche"),
    EOS("EOS", "EOS"),
    XTZ("XTZ", "Tezos"),
    NEAR("NEAR", "NEAR Protocol"),
    ALGO("ALGO", "Algorand"),
    DOT("DOT", "Polkadot"),
    CELO("CELO", "Celo");

    override fun toString(): String = code
}

/**
 * Enum class representing supported network codes.
 */
enum class NetworkCode(val code: String, val displayName: String) {
    ERC20("ERC20", "Ethereum"),
    MATIC20("MATIC20", "Polygon"),
    BEP20("BEP20", "Binance Smart Chain"),
    BEP2("BEP2", "Binance Chain"),
    SPL("SPL", "Solana"),
    TRC20("TRC20", "Tron"),
    AVAXC("AVAXC", "Avalanche C-Chain"),
    EOS("EOS", "EOS"),
    XTZ("XTZ", "Tezos"),
    NEAR("NEAR", "NEAR Protocol"),
    ALGO("ALGO", "Algorand"),
    STATEMINT("STATEMINT", "Polkadot Statemint"),
    ARBITRUM("ARBITRUM", "Arbitrum"),
    OPTIMISM("OPTIMISM", "Optimism"),
    CELO("CELO", "Celo");

    override fun toString(): String = code
}

/**
 * Data class for network options.
 */
data class NetworkOption(
    val name: String,
    val coinCode: CryptoCode,
    val network: NetworkCode,
    val description: String,
    val category: String,
)

// List of all supported networks
val networkOptions = listOf(
    // Ethereum Ecosystem
    NetworkOption(
        "Ethereum",
        CryptoCode.ETH,
        NetworkCode.ERC20,
        "Most established network",
        "Ethereum Ecosystem"
    ),
    NetworkOption(
        "USDT on Ethereum",
        CryptoCode.USDT,
        NetworkCode.ERC20,
        "Ethereum stablecoin",
        "Ethereum Ecosystem"
    ),

    // Layer 2 Solutions
    NetworkOption(
        "Polygon",
        CryptoCode.MATIC,
        NetworkCode.MATIC20,
        "Fast & low fees",
        "Layer 2 Solutions"
    ),
    NetworkOption(
        "Arbitrum",
        CryptoCode.ETH,
        NetworkCode.ARBITRUM,
        "High performance L2",
        "Layer 2 Solutions"
    ),
    NetworkOption(
        "Optimism",
        CryptoCode.ETH,
        NetworkCode.OPTIMISM,
        "Fast & secure L2",
        "Layer 2 Solutions"
    ),

    // Binance Ecosystem
    NetworkOption(
        "BNB Smart Chain",
        CryptoCode.BNB,
        NetworkCode.BEP20,
        "Binance Smart Chain",
        "Binance Ecosystem"
    ),
    NetworkOption(
        "BNB Chain",
        CryptoCode.BNB,
        NetworkCode.BEP2,
        "Binance Chain",
        "Binance Ecosystem"
    ),
    NetworkOption(
        "USDT on BSC",
        CryptoCode.USDT,
        NetworkCode.BEP20,
        "BSC stablecoin",
        "Binance Ecosystem"
    ),

    // Other Major Networks
    NetworkOption(
        "Solana",
        CryptoCode.SOL,
        NetworkCode.SPL,
        "Ultra fast & low cost",
        "Other Major Networks"
    ),
    NetworkOption(
        "USDT on Tron",
        CryptoCode.USDT,
        NetworkCode.TRC20,
        "Tron network",
        "Other Major Networks"
    ),
    NetworkOption(
        "Avalanche",
        CryptoCode.AVAX,
        NetworkCode.AVAXC,
        "Fast & scalable",
        "Other Major Networks"
    ),

    // Alternative Networks
    NetworkOption(
        "EOS",
        CryptoCode.EOS,
        NetworkCode.EOS,
        "High performance blockchain",
        "Alternative Networks"
    ),
    NetworkOption(
        "Tezos",
        CryptoCode.XTZ,
        NetworkCode.XTZ,
        "Self-amending blockchain",
        "Alternative Networks"
    ),
    NetworkOption(
        "NEAR",
        CryptoCode.NEAR,
        NetworkCode.NEAR,
        "Sharded blockchain",
        "Alternative Networks"
    ),
    NetworkOption(
        "Algorand",
        CryptoCode.ALGO,
        NetworkCode.ALGO,
        "Pure proof of stake",
        "Alternative Networks"
    ),
    NetworkOption(
        "Polkadot",
        CryptoCode.DOT,
        NetworkCode.STATEMINT,
        "Parachain",
        "Alternative Networks"
    ),
    NetworkOption(
        "Celo",
        CryptoCode.CELO,
        NetworkCode.CELO,
        "Mobile-first blockchain",
        "Alternative Networks"
    )
)

@Composable
fun NetworkOptionCard(
    option: NetworkOption,
    onSelect: (CryptoCode, NetworkCode) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onSelect(option.coinCode, option.network) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = option.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = option.description,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
fun CategoryHeader(
    category: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = category,
        style = MaterialTheme.typography.titleLarge,
        modifier = modifier.padding(vertical = 16.dp)
    )
}

@Composable
fun OnrampScreen(
    modifier: Modifier = Modifier,
    onLaunchOnramp: (CryptoCode, NetworkCode) -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxSize(),
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    text = "Select Network & Token",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }

            networkOptions
                .groupBy { it.category }
                .forEach { (category, options) ->
                    item {
                        CategoryHeader(category = category)
                    }

                    items(
                        items = options,
                        key = { "${it.coinCode}_${it.network}" }
                    ) { option ->
                        NetworkOptionCard(
                            option = option,
                            onSelect = onLaunchOnramp
                        )
                    }
                }
        }
    }
}


